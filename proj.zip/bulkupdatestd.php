<?php
// Start the session
session_start();
?>

<html>
<head>
<title>Islamic Public School Fee System</title>
<link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class=wraper>
<a href=index.php>Home</a> - Update Bulk Students

<h2>Update Bulk Students</h2>

<ul>
<li><a href="updatebyall.php">Update All Active Students</a></li>
<li><a href="updatebyclass.php">Update by Class</a></li>
<li><a href="updatebyfamily.php">Update by Family</a></li>
</ul>
</div>
</body>
</html>